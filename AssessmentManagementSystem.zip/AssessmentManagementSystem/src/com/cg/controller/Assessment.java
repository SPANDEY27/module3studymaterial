package com.cg.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Assessment")
public class Assessment extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Assessment() {
        super();
    }
    public int average;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String module1no=request.getParameter("module1");
		String module2no=request.getParameter("module2");
		String module3no=request.getParameter("module3");
		String module4no=request.getParameter("module4");
		
		average=(Integer.parseInt(module1no)+Integer.parseInt(module2no)+Integer.parseInt(module3no)+Integer.parseInt(module4no))/4;
		
		if(average>=60) {
			response.sendRedirect("Success.jsp?per="+ average);
		}
		else
		{
			response.sendRedirect("Fail.jsp?pers="+ average);
		}
	}

}
