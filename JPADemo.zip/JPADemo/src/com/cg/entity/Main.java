package com.cg.entity;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

		EntityManagerFactory  emf=Persistence.createEntityManagerFactory("MyJPA");
		EntityManager em=emf.createEntityManager();
		
		public void getStudentById(int id)
		{
			Student student=em.find(Student.class, id);
		}
		
		public void addStudent(Student student)
		{
			em.persist(student);
		}
		
		public void removeStudent(Student student)
		{
			em.remove(student);
		}
		
		public void updateStudent(Student student)
		{
			em.merge(student);
		}
		
		public void beginTransaction()
		{
			em.getTransaction().begin();
		}
	
		public void commitTransaction()
		{
			em.getTransaction().commit();
		}
		public void closeTransaction() {
			System.out.println("Added one student to database");
			em.close();
			emf.close();
		}
		public static void main(String args[]) {
			Main m=new Main();
			m.beginTransaction();
			Scanner sc=new Scanner(System.in);
			Student student=new Student();
			
			System.out.println("Enter the name");
			String name=sc.next();
			student.setName(name);
			
			m.addStudent(student);
			m.updateStudent(student);
			m.removeStudent(student);
			
			
			m.commitTransaction();
			m.closeTransaction();
				
		}
		
		
	

}
