package com.cg.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CreditCard")
public class CreditCard extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public CreditCard() {
        super();
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long ccno =  Long.parseLong(request.getParameter("ccno"));
        int cvv = Integer.parseInt(request.getParameter("cvv"));
        long accno =  Long.parseLong(request.getParameter("accno"));
        String bn = request.getParameter("bname");
        
        if(String.valueOf(ccno).length()==16 && bn.equals("HSBC"))
        {
            RequestDispatcher rd = request.getRequestDispatcher("Success.jsp");
            rd.forward(request,response);
        }
        else
        {
            RequestDispatcher rd = request.getRequestDispatcher("Failure.jsp");
            rd.forward(request,response);
        }
	}

}
